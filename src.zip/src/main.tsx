import React from "react";
import ReactDOM from "react-dom/client";
import { RouterProvider } from "react-router-dom";

import { router } from "./app/routes";

import "./index.css";

import "./styles/dashboard.css";
import "./styles/header.css";
import "./styles/layout.css";
import "./styles/sidebar.css";
import "./styles/variables.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>,
);
